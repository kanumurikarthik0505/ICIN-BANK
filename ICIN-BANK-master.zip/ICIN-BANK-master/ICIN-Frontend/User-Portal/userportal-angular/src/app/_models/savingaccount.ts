export class SavingAccount{
    id:number;
    accno:number;
    balance:number;
    username:String;
    user:null;
}